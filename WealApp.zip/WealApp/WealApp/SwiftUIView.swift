//
//  SwiftUIView.swift
//  WealApp
//
//  Created by Bayan Nayf on 18/05/1444 AH.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        VStack(alignment: .trailing, spacing: 0){
                   
                   Text("الافراد")
                       .font(.system(size: 25))
                       .padding(16.0)
                   

                   HStack(alignment: .center){
                       Spacer()
                       ZStack(alignment: .top){
                           Image("img")
                               .resizable()
                               .frame(width: 300, height: 150)
                           Text("500,16 SR")
                               .font(.system(size: 18)
                                   .bold())
                               .foregroundColor(Color("ColorB"))
                               .padding(.top,20)
                               
                       }
                       .padding(.bottom,16)
                       .cornerRadius(15).overlay(
                           RoundedRectangle(cornerRadius: 15)
                               .stroke(.black, lineWidth: 1)
                       )
                       Spacer()
                   }

                   HStack(spacing:15){
                       Button {
                           
                       } label: {
                       
                       }.frame(width: 20, height: 20)
                       
                       Text("June 2020")
                           .font(.system(size: 14)
                           .bold())
                       Button {
                           
                       } label: {
                           Image(systemName: "chevron.right")
                       }
                       Spacer()
                       Button {
                           
                       } label: {
                           Image(systemName: "chevron.backward")
                       }.frame(width: 20, height: 20)
                       
                       
                       Button {
                           
                       } label: {
                           Image(systemName: "chevron.right")
                       }.frame(width: 20, height: 20)

                   }.padding(16)
                   
                   
                   HStack( spacing:20){
                       Spacer()
                       VStack{
                           Text("دخل")
                           Text("500")
                       }.frame(width: 150, height: 80, alignment: .center).background(Color("ColorB")).border(.black, width: 1) .cornerRadius(10).foregroundColor(.white)
                       
                       VStack{
                           Text("مصاريف")
                           Text("100")
                       }.frame(width: 150, height: 80, alignment: .center).background(Color("ColorB")).border(.black, width: 1) .cornerRadius(10).foregroundColor(.white)
                       
                       Spacer()
                   }
                   Text("اليوم").font(.system(size: 25)).padding(16)
                   HStack( spacing:10){
                       Spacer()
                       Text("20").font(.system(size: 15))
                       Image(systemName: "chevron.up.circle").foregroundColor(.blue)
                       Text("60").font(.system(size: 15))
                       Image(systemName: "chevron.down.circle").foregroundColor(.blue)
                       Spacer()
                   }.padding(.top, -20)
                   
                   VStack(alignment: .leading, spacing:10){
                      
                           HStack( spacing:7){
                               Spacer()
                               Text("سيارة")
                               Image("carpool").resizable().frame(width: 20, height: 20).padding(10)
                               
                           }.background(.white) .cornerRadius(10).overlay(
                               RoundedRectangle(cornerRadius: 10)
                                   .stroke(.gray, lineWidth: 1)
                           ).padding(.horizontal)
                           
                           HStack( spacing:7){
                               Spacer()
                               Text("هدية")
                               Image("gift").resizable().frame(width: 20, height: 20).padding(10)
                               
                           }.background(.white) .cornerRadius(10).overlay(
                               RoundedRectangle(cornerRadius: 10)
                                   .stroke(.gray, lineWidth: 1)
                           ).padding(.horizontal)
                     
                   }.padding(.top, 10)
                   Spacer()
                   HStack{
                   Button {
                       
                   } label: {
                       Image(systemName: "plus.circle").resizable().frame(width: 35, height: 35)
                  
                   }.padding(50)
                       
                       Spacer()
                   }
               }

               }
               
                   
           
       }






struct SwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIView()
    }
}




