//
//  View3.swift
//  WealApp
//
//  Created by Ahad on 17/05/1444 AH.
//

import SwiftUI
struct View3: View{
    
    @State var x: String=""
    @State var y: String=""
    @State var z: String=""
    
    
    var body: some View {
        
        
        
        VStack (spacing:20) {
            
            //   Spacer ()
            
            Text("اسم القائمة")
            
                .font(.title)
            
                .fontWeight(.bold)
            
                .multilineTextAlignment(.center)
            
                .foregroundColor(Color.black)
            
                .padding(50.0)
            
                .frame(width:900.0,height:100.0)
            
            VStack(alignment: .leading, spacing:40){
                
                HStack( spacing:7){
                    Spacer()
                    TextField( "ادخل المهمة", text: $x)
                        .padding(.leading, 98.0)
                    
                    Image(systemName: "circle").resizable().foregroundColor(Color("ColorB")).frame(width: 30, height: 30).padding(12)
                    
                    
                }.background(.white) .cornerRadius(10).overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color("ColorA"), lineWidth: 2)                    ).padding(.horizontal, 48.0)
                
                HStack( spacing:7){
                    Spacer()
                    TextField( "ادخل المهمة", text: $y)
                        .padding(.leading, 98.0)
                    
                    Image(systemName: "circle").resizable().foregroundColor(Color("ColorB")).frame(width: 30, height: 30).padding(12)
                    
                }.background(.white) .cornerRadius(10).overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color("ColorA"), lineWidth: 2)                    ).padding(.horizontal,48.0)
                HStack( spacing:7){
                    Spacer()
                    TextField( "ادخل المهمة", text: $z)
                        .padding(.leading, 98.0)
                    
                    Image(systemName: "circle").resizable().foregroundColor(Color("ColorB")).frame(width: 30, height: 30).padding(12)
                    
                }.background(.white) .cornerRadius(10).overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color("ColorA"), lineWidth: 2)
                ).padding(.horizontal,48.0)}
            Divider()
                .frame(height: 30.0)
            
            
            
            VStack(alignment: .center, spacing:40){
                
                HStack( spacing:4){
                    //   Spacer()
                    Text( "مكتمل")
                        .foregroundColor(Color.white)
                        .padding(.leading, 40.0)
                    
                    Image(systemName: "chevron.down").resizable().foregroundColor(.white).frame(width: 17.0, height: 10.0).padding(12)
                    
                    
                }.background(Color("ColorB")) .cornerRadius(0).overlay(
                    RoundedRectangle(cornerRadius: 0)
                        .stroke(Color("ColorA"), lineWidth: 2)                    ).padding(.leading, 53.0)
                
            }
            .padding(.leading, 84.0)
          
            VStack(alignment: .leading, spacing:40){
                
                HStack( spacing:7){
                    Spacer()
                    TextField( "ادخل المهمة", text: $x)
                        .padding(.leading, 98.0)
                    
                    Image(systemName: "checkmark.circle.fill").resizable().foregroundColor(Color("ColorB")).frame(width: 30, height: 30).padding(12)
                    
                    
                }.background(.white) .cornerRadius(10).overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color("ColorA"), lineWidth: 2)                    ).padding(.horizontal, 48.0)
                
            }
            VStack(alignment: .leading, spacing:40){
                
                HStack( spacing:7){
                    Spacer()
                    TextField( "ادخل المهمة", text: $x)
                        .padding(.leading, 98.0)
                    
                    Image(systemName: "checkmark.circle.fill").resizable().foregroundColor(Color("ColorB")).frame(width: 30, height: 30).padding(12)
                    
                    
                }.background(.white) .cornerRadius(10).overlay(
                    RoundedRectangle(cornerRadius: 20)
                        .stroke(Color("ColorA"), lineWidth: 2)                    ).padding(.horizontal, 48.0)
            }
        }
        
      
        
    }
    
    
    struct View3_Previews: PreviewProvider {
        static var previews: some View {
            View3()
        }
    }}
