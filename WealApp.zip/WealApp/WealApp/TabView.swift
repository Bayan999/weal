//
//  TabView.swift
//  WealApp
//
//  Created by mac on 12/12/2022.
//

import Foundation
import SwiftUI
struct TabBarView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State var tabBarIsHidden = false
    
    init() {
    UITabBar.appearance().backgroundColor = UIColor.white

    }
    
    var body: some View {
        TabView {

            assel().onAppear(){
                tabBarIsHidden = false
            }
                .tabItem {
                    Label("الرئيسية", systemImage:
                            "square.grid.2x2")
                }

//            Button( action: {}, label: {
//                
//            })
//                .onAppear(){
//                self.presentationMode.wrappedValue.dismiss()
//            }
            ContentView().onAppear(){
                tabBarIsHidden = true
            }
                .tabItem {
                    Label("الرئيسية", systemImage:
                            "checklist")
                }



        }
            .navigationBarBackButtonHidden(tabBarIsHidden)
    }
}

struct TabBarView_Previews: PreviewProvider {
//    @Binding var rootIsActive
    static var previews: some View {
        TabBarView( )
    }
}
