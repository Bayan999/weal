//
//  assel.swift
//  WealApp
//
//  Created by Bayan Nayf on 18/05/1444 AH.
//

import SwiftUI

struct assel: View {
   
        @State var x = ""
          @State var y = ""
          
          
        
    var body: some View {
       
              NavigationView{
                  VStack {
                      
                      HStack {
                          TextField("ادخل أسمك",text:$y).font(.title2)
                              .padding(.leading, 114.0)
                              
                          Text("مرحبا..")
                              .font(.title)
                              .fontWeight(.bold)
                              .foregroundColor(Color.black)
                              .padding(.trailing, 61.0)

                          
                      }
                          Button(action: {}, label: {
                              VStack( spacing:20){
                                  
                                  // Spacer()
                                  //.padding(-1.0)
                                  VStack{
                                      Text("ميزانيه المشروع")
                                          .font(.largeTitle)
                                          .fontWeight(.bold)
                                          .foregroundColor(Color.white)
                                      TextField("ادخل الميزانية",text:$x).font(.title2)
                                          .accentColor(Color.black)
                                  }.frame(width: 310, height: 180, alignment: .center).background(Color("ColorB")).border(.black, width: 1) .cornerRadius(30).foregroundColor(.black)
                                  
                                  NavigationLink{
                                      ProjectPlan()
                                  }
                              label: {
                                  
                                  VStack{
                                      Text("خطه المشروع")
                                          .font(.largeTitle)
                                          .fontWeight(.bold)
                                          .foregroundColor(Color.white)
                                      
                                  }.frame(width: 310, height: 180, alignment: .center).background(Color("ColorB")).border(.black, width: 1) .cornerRadius(30).foregroundColor(.black)
                                  
                              }
                                  
                                  
                                  
                                  
                              .padding(.vertical, 10)
                                  
                              }
                              
                          })
                      }
                  .navigationBarTitleDisplayMode(.inline)
              }
              }
          }
          
          
    

struct assel_Previews: PreviewProvider {
    static var previews: some View {
        assel()
    }
}


