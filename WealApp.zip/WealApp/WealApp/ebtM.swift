//
//  ebtM.swift
//  WealApp
//
//  Created by Bayan Nayf on 18/05/1444 AH.
//

import SwiftUI

struct ebtM: View {
    @State var isActive : Bool = false
    @State var x = ""
    var body: some View {
        NavigationView {
            
            VStack(alignment:.center, spacing:40.0){
                HStack( spacing:10){
                    // Spacer()
                    
                    TextField("ادخل اسمك", text:$x).font(.title2).padding(.leading, 101.0)
                    
                    Text("مرحبا..")
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.horizontal, 42.0)
                }
                
                NavigationLink{
                    SwiftUIView()
                } label:{
                    VStack(alignment: .leading, spacing:40){
                        
                        HStack( spacing:20){
                            Spacer()
                            Text("الافراد")
                                .foregroundColor(Color("ColorB"))
                                .font(.title)
                                .fontWeight(.bold)
                            Image("22").resizable().frame(width: 70, height: 70).padding(30)
                            
                        }.background(.white) .cornerRadius(15).overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color("ColorA"), lineWidth: 2)
                        ).padding(.horizontal)
                    }
                }
                
                
                NavigationLink{
                    TabBarView()
                } label:{
                    VStack(alignment: .leading, spacing:40){
                        HStack( spacing:15){
                            Spacer()
                            Image("11").resizable().frame(width: 70, height: 70).padding(30)
                            
                            Text("المشاريع")
                                .foregroundColor(Color("ColorB"))
                                .font(.title)
                                .fontWeight(.bold).padding([.top, .bottom, .trailing], 40)
                        }.background(.white) .cornerRadius(10).overlay(
                            RoundedRectangle(cornerRadius: 25)
                                .stroke(Color("ColorA"), lineWidth: 2)
                        ).padding(.horizontal)
                        
                    }}
                
               
                
                
                
                HStack(alignment: .center){
                    
                    ZStack(alignment: .bottom){
                        Spacer()
                        Image("55")
                            .resizable()
                            .frame(width: 400, height: 200)
                            .padding(.bottom)
                        
                        
                    }
                    
                    
                    
                }
                
            }}
    }}
        struct ebtM_Previews: PreviewProvider {
            static var previews: some View {
                ebtM()
            }
        }
        
        
   
