//
//  ProjectPlan.swift
//  WealApp
//
//  Created by mac on 13/12/2022.
//

import Foundation
import SwiftUI
struct ProjectPlan: View {

    
    
    var body: some View {
//        NavigationView {
          
            
            
        VStack {

                    ScrollView {

                        

                        Text("خطة المشروع")

                            .font(.title)

                            .fontWeight(.semibold)

                            .foregroundColor(Color("ColorB"))

                            .multilineTextAlignment(.center)

                            .padding(.top, 190.0)

                            .frame(height: 50.0)

                        

                        

                        Image("a1")

                            .resizable(capInsets: EdgeInsets())

                            .aspectRatio(contentMode: .fit)

                            .padding(.vertical, 100.0)

                            .frame(width: 380.0)

                        

                        Text("جدول الطلبات")

                            .font(.title)

                            .fontWeight(.semibold)

                            .foregroundColor(Color("ColorB"))

                            .multilineTextAlignment(.center)

                            .padding(.top, 10.0)

                            .frame(height: 50.0)

                        

                        Image("a2")

                            .resizable(capInsets: EdgeInsets())

                            .aspectRatio(contentMode: .fit)

                            .padding(.vertical, 10.0)

                            .frame(width: 380.0)

                        

                        Text("الأحصائيات")

                            .font(.title)

                            .fontWeight(.semibold)

                            .foregroundColor(Color("ColorB"))

                            .multilineTextAlignment(.center)

                            .padding(.bottom, -200.0)

                            .frame(height: 50.0)

                        Image("a3")

                            .resizable(capInsets: EdgeInsets())

                            .aspectRatio(contentMode: .fit)

                            .padding(.vertical, 10.0)

                            .frame(width: 380.0)

                        

                        

                        

                    }

                    

                  

                    

                        

                        

                }
        .navigationBarTitleDisplayMode(.inline)
    }
    
}
    struct ProjectPlan_Previews: PreviewProvider {
        static var previews: some View {
            ProjectPlan()
        }
        
    }





    
