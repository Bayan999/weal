//
//  View2.swift
//  WealApp
//
//  Created by Ahad on 16/05/1444 AH.
//

import SwiftUI
struct View2: View {
    @State var textfieldText: String=""
    @State var textfieldT: String=""
    @State var textfieldTe: String=""
    
    
    var body: some View {

          
            
            
            VStack (spacing:30) {
                
                Spacer ()
                
                Text("قائمة المهام")
                
                
                    .font(.title)
                
                    .fontWeight(.bold)
                
                    .multilineTextAlignment(.center)
                
                    .foregroundColor(Color.black)
                
                    .padding(.top, 50.0)
                
                    .frame(width:900.0,height:100.0)
                
                VStack(alignment: .leading, spacing:40){
                    
                    HStack( spacing:7){
                        Spacer()
                        TextField( "ادخل اسم القائمة", text: $textfieldT)
                            .padding(.leading, 98.0)
                        
                        Image(systemName: "list.bullet.circle.fill").resizable().foregroundColor(Color("ColorB")).frame(width: 30, height: 30).padding(12)
                        
                        
                    }.background(.white) .cornerRadius(10).overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color("ColorA"), lineWidth: 2)                    ).padding(.horizontal, 48.0)
                    
                    HStack( spacing:7){
                        Spacer()
                        TextField( "ادخل اسم القائمة", text: $textfieldTe)
                            .padding(.leading, 98.0)
                        
                        Image(systemName: "list.bullet.circle.fill").resizable().foregroundColor(Color("ColorB")).frame(width: 30, height: 30).padding(12)
                        
                    }.background(.white) .cornerRadius(10).overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color("ColorA"), lineWidth: 2)                    ).padding(.horizontal,48.0)
                    HStack( spacing:7){
                        Spacer()
                        TextField( "ادخل اسم القائمة", text: $textfieldText)
                            .padding(.leading, 98.0)
                        
                        Image(systemName: "list.bullet.circle.fill").resizable().foregroundColor(Color("ColorB")).frame(width: 30, height: 30).padding(12)
                        
                    }.background(.white) .cornerRadius(10).overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color("ColorA"), lineWidth: 2)
                    ).padding(.horizontal,48.0)}
                Divider()
                    .frame(height: 30.0)
               
               //  Spacer()
                
              
                                        
                VStack{
                    
                    NavigationLink {
                        View3()
                    } label: {
                       
                        Text("قائمة جديدة")
                            .fontWeight(.black)
                            .foregroundColor(Color.black)
                            .multilineTextAlignment(.trailing)
                            .padding(.leading, -100.0)
                            .frame(width: 1.0, height: 2.0)
                        
                        Image(systemName: "plus.circle").resizable().foregroundColor(Color("ColorB")).padding(-2.0).frame(width: 35, height: 35.0)
                        
                    }.padding(.leading, 292.0)
                    Spacer()
                    
                    
                    
                    
                }
                .padding(.trailing, 47.0)
                Spacer ()
//            
            .navigationBarTitleDisplayMode(.inline)
        }
       
    }
    
    
    struct View2_Previews: PreviewProvider {
        static var previews: some View {
            View2()
        }
        
    }
}
